﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.bttnload = New System.Windows.Forms.Button()
        Me.bttnsv = New System.Windows.Forms.Button()
        Me.textBox1 = New System.Windows.Forms.TextBox()
        Me.bttnangry = New System.Windows.Forms.Button()
        Me.bttnksl = New System.Windows.Forms.Button()
        Me.bttnsly = New System.Windows.Forms.Button()
        Me.bttnsd = New System.Windows.Forms.Button()
        Me.button2 = New System.Windows.Forms.Button()
        Me.bttnhppy = New System.Windows.Forms.Button()
        Me.lblJudul = New System.Windows.Forms.Label()
        Me.bttndel = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'bttnload
        '
        Me.bttnload.BackColor = System.Drawing.Color.SpringGreen
        Me.bttnload.Font = New System.Drawing.Font("Comic Sans MS", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bttnload.Location = New System.Drawing.Point(269, 406)
        Me.bttnload.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.bttnload.Name = "bttnload"
        Me.bttnload.Size = New System.Drawing.Size(64, 26)
        Me.bttnload.TabIndex = 21
        Me.bttnload.Text = "Load"
        Me.bttnload.UseVisualStyleBackColor = False
        '
        'bttnsv
        '
        Me.bttnsv.BackColor = System.Drawing.Color.DodgerBlue
        Me.bttnsv.Font = New System.Drawing.Font("Comic Sans MS", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bttnsv.Location = New System.Drawing.Point(191, 406)
        Me.bttnsv.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.bttnsv.Name = "bttnsv"
        Me.bttnsv.Size = New System.Drawing.Size(64, 26)
        Me.bttnsv.TabIndex = 20
        Me.bttnsv.Text = "Save"
        Me.bttnsv.UseVisualStyleBackColor = False
        '
        'textBox1
        '
        Me.textBox1.Font = New System.Drawing.Font("Comic Sans MS", 7.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.textBox1.Location = New System.Drawing.Point(108, 198)
        Me.textBox1.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.textBox1.Multiline = True
        Me.textBox1.Name = "textBox1"
        Me.textBox1.Size = New System.Drawing.Size(376, 204)
        Me.textBox1.TabIndex = 19
        Me.textBox1.Text = "Curhat disiniii yeaahh!"
        '
        'bttnangry
        '
        Me.bttnangry.FlatAppearance.BorderSize = 0
        Me.bttnangry.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bttnangry.Font = New System.Drawing.Font("Comic Sans MS", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bttnangry.ForeColor = System.Drawing.Color.Indigo
        Me.bttnangry.Image = CType(resources.GetObject("bttnangry.Image"), System.Drawing.Image)
        Me.bttnangry.Location = New System.Drawing.Point(450, 76)
        Me.bttnangry.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.bttnangry.Name = "bttnangry"
        Me.bttnangry.Size = New System.Drawing.Size(91, 91)
        Me.bttnangry.TabIndex = 18
        Me.bttnangry.Text = "HHHHRRRRRR!!!!"
        Me.bttnangry.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.bttnangry.UseVisualStyleBackColor = True
        '
        'bttnksl
        '
        Me.bttnksl.FlatAppearance.BorderSize = 0
        Me.bttnksl.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bttnksl.Font = New System.Drawing.Font("Comic Sans MS", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bttnksl.ForeColor = System.Drawing.Color.Indigo
        Me.bttnksl.Image = CType(resources.GetObject("bttnksl.Image"), System.Drawing.Image)
        Me.bttnksl.Location = New System.Drawing.Point(352, 76)
        Me.bttnksl.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.bttnksl.Name = "bttnksl"
        Me.bttnksl.Size = New System.Drawing.Size(91, 91)
        Me.bttnksl.TabIndex = 17
        Me.bttnksl.Text = "Jangan Ganggu!"
        Me.bttnksl.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.bttnksl.UseVisualStyleBackColor = True
        '
        'bttnsly
        '
        Me.bttnsly.FlatAppearance.BorderSize = 0
        Me.bttnsly.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bttnsly.Font = New System.Drawing.Font("Comic Sans MS", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bttnsly.ForeColor = System.Drawing.Color.Indigo
        Me.bttnsly.Image = CType(resources.GetObject("bttnsly.Image"), System.Drawing.Image)
        Me.bttnsly.Location = New System.Drawing.Point(255, 76)
        Me.bttnsly.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.bttnsly.Name = "bttnsly"
        Me.bttnsly.Size = New System.Drawing.Size(91, 91)
        Me.bttnsly.TabIndex = 16
        Me.bttnsly.Text = "Slayy"
        Me.bttnsly.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.bttnsly.UseVisualStyleBackColor = True
        '
        'bttnsd
        '
        Me.bttnsd.FlatAppearance.BorderSize = 0
        Me.bttnsd.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bttnsd.Font = New System.Drawing.Font("Comic Sans MS", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bttnsd.ForeColor = System.Drawing.Color.Indigo
        Me.bttnsd.Image = CType(resources.GetObject("bttnsd.Image"), System.Drawing.Image)
        Me.bttnsd.Location = New System.Drawing.Point(158, 76)
        Me.bttnsd.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.bttnsd.Name = "bttnsd"
        Me.bttnsd.Size = New System.Drawing.Size(91, 91)
        Me.bttnsd.TabIndex = 15
        Me.bttnsd.Text = "Hmmmm"
        Me.bttnsd.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.bttnsd.UseVisualStyleBackColor = True
        '
        'button2
        '
        Me.button2.Font = New System.Drawing.Font("Segoe UI Emoji", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.button2.Image = CType(resources.GetObject("button2.Image"), System.Drawing.Image)
        Me.button2.Location = New System.Drawing.Point(73, -66)
        Me.button2.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(0, 0)
        Me.button2.TabIndex = 14
        Me.button2.Text = "Senanggg"
        Me.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.button2.UseVisualStyleBackColor = True
        '
        'bttnhppy
        '
        Me.bttnhppy.FlatAppearance.BorderSize = 0
        Me.bttnhppy.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bttnhppy.Font = New System.Drawing.Font("Comic Sans MS", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bttnhppy.ForeColor = System.Drawing.Color.Indigo
        Me.bttnhppy.Image = CType(resources.GetObject("bttnhppy.Image"), System.Drawing.Image)
        Me.bttnhppy.Location = New System.Drawing.Point(60, 76)
        Me.bttnhppy.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.bttnhppy.Name = "bttnhppy"
        Me.bttnhppy.Size = New System.Drawing.Size(91, 91)
        Me.bttnhppy.TabIndex = 13
        Me.bttnhppy.Text = "Senanggg Sekali"
        Me.bttnhppy.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.bttnhppy.UseVisualStyleBackColor = True
        '
        'lblJudul
        '
        Me.lblJudul.AutoSize = True
        Me.lblJudul.Font = New System.Drawing.Font("Comic Sans MS", 15.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblJudul.ForeColor = System.Drawing.Color.Indigo
        Me.lblJudul.Location = New System.Drawing.Point(104, 27)
        Me.lblJudul.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblJudul.Name = "lblJudul"
        Me.lblJudul.Size = New System.Drawing.Size(453, 29)
        Me.lblJudul.TabIndex = 22
        Me.lblJudul.Text = "Halooooo Bagaimana Perasaanmu Hari ini???!!"
        '
        'bttndel
        '
        Me.bttndel.BackColor = System.Drawing.Color.Red
        Me.bttndel.Font = New System.Drawing.Font("Comic Sans MS", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bttndel.Location = New System.Drawing.Point(352, 406)
        Me.bttndel.Margin = New System.Windows.Forms.Padding(2)
        Me.bttndel.Name = "bttndel"
        Me.bttndel.Size = New System.Drawing.Size(64, 26)
        Me.bttndel.TabIndex = 23
        Me.bttndel.Text = "Delete"
        Me.bttndel.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightPink
        Me.ClientSize = New System.Drawing.Size(600, 441)
        Me.Controls.Add(Me.bttndel)
        Me.Controls.Add(Me.lblJudul)
        Me.Controls.Add(Me.bttnload)
        Me.Controls.Add(Me.bttnsv)
        Me.Controls.Add(Me.textBox1)
        Me.Controls.Add(Me.bttnangry)
        Me.Controls.Add(Me.bttnksl)
        Me.Controls.Add(Me.bttnsly)
        Me.Controls.Add(Me.bttnsd)
        Me.Controls.Add(Me.button2)
        Me.Controls.Add(Me.bttnhppy)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents bttnload As Button
    Private WithEvents bttnsv As Button
    Private WithEvents textBox1 As TextBox
    Private WithEvents bttnangry As Button
    Private WithEvents bttnksl As Button
    Private WithEvents bttnsly As Button
    Private WithEvents bttnsd As Button
    Private WithEvents button2 As Button
    Private WithEvents bttnhppy As Button
    Friend WithEvents lblJudul As Label
    Private WithEvents bttndel As Button
End Class
