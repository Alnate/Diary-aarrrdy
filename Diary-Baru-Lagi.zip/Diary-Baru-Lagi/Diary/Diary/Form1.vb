﻿Imports System.IO

Public Class Form1

    Dim currentMood As String = ""
    Dim filePath As String = "diary.txt"

    Private Sub SetMood(mood As String, warna As Color)

        currentMood = mood
        Me.BackColor = warna

        lblJudul.Text = "Hari ini kamu merasa : " & mood

    End Sub


    Private Sub bttnhppy_Click(sender As Object, e As EventArgs) Handles bttnhppy.Click
        SetMood("Senang Sekali 😊", Color.LightPink)
    End Sub

    Private Sub bttnsd_Click(sender As Object, e As EventArgs) Handles bttnsd.Click
        SetMood("Hmmm 😔", Color.LightBlue)
    End Sub

    Private Sub bttnksl_Click(sender As Object, e As EventArgs) Handles bttnksl.Click
        SetMood("Slayy 😮‍💨", Color.Bisque)
    End Sub

    Private Sub bttnangry_Click(sender As Object, e As EventArgs) Handles bttnangry.Click
        SetMood("Jangan Ganggu 😡", Color.LightCoral)
    End Sub


    Private Sub bttnsv_Click(sender As Object, e As EventArgs) Handles bttnsv.Click

        If textBox1.Text = "" Then
            MessageBox.Show("Diary masih kosong 😭")
            Exit Sub
        End If

        Using writer As StreamWriter = New StreamWriter(filePath, True)

            writer.WriteLine("Tanggal : " & DateTime.Now)
            writer.WriteLine("Mood : " & currentMood)
            writer.WriteLine("Cerita : ")


            For Each line As String In textBox1.Lines
                writer.WriteLine(line)
            Next

            writer.WriteLine("----------------------")

        End Using

        MessageBox.Show("Diary berhasil disimpan 💖")

    End Sub

    Private Sub bttnload_Click(sender As Object, e As EventArgs) Handles bttnload.Click

        If Not File.Exists(filePath) Then
            MessageBox.Show("Belum ada diary tersimpan 😢")
            Exit Sub
        End If

        Dim isi As String = File.ReadAllText(filePath)

        If isi.Trim() = "" Then
            MessageBox.Show("Diary masih kosong 😭")
        Else
            textBox1.Text = isi
        End If

    End Sub


    Private Sub bttndel_Click(sender As Object, e As EventArgs) Handles bttndel.Click
        Dim tanya As DialogResult = MessageBox.Show("Hapus semua pesan di diary?", "Konfirmasi", MessageBoxButtons.YesNo, MessageBoxIcon.Warning)
        If tanya = DialogResult.Yes Then

            File.WriteAllText(filePath, "")

            textBox1.Clear()

            MessageBox.Show("Semua pesan sudah dihapus! ✨")
        End If
    End Sub
End Class
